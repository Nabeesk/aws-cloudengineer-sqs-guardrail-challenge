# Cloud Engineer Guardrail Challenge: SQS Security Compliance

From the understanding of the details, this project implements an enterprise-grade guardrail for newly created Amazon SQS queues. The solution uses AWS CloudFormation (YAML only) to deploy required resources and a Python Lambda function to validate SQS queue security configurations. I have added an additional GitHub Actions workflow to demonstrate CI/CD best practices.

## File Structure

CloudGuardRailChallenge.zip 
├── README.md # This documentation file 
├── template.yaml # CloudFormation template in YAML 
├── .github/ 
│ └── workflows/ 
│   └── ci.yml # GitHub Actions workflow file (Bonus) 
└── lambda_function/ └── lambda_function.py # Python Lambda function code


## Deployment Instructions

### Prerequisites

- AWS CLI installed and configured.
- Necessary AWS permissions (including capabilities for IAM and CloudFormation).
- (Optional) GitHub repository secrets configured if using GitHub Actions for deployment:
  - `AWS_ACCESS_KEY_ID`
  - `AWS_SECRET_ACCESS_KEY`
  - `PERMISSION_BOUNDARY_ARN` (ARN for your IAM permission boundary)

### Deploying the CloudFormation Stack

1. **Clone/Fork the Repository:**
   - Fork the repository on GitHub.
   - Clone your fork locally.

2. **Update Parameters (if needed):**
   - Open `template.yaml` and update or override parameters such as:
     - `LambdaRuntime` (e.g., `python3.9`)
     - `LambdaMemorySize` (e.g., `128`)
     - `PermissionBoundaryARN` (Your IAM permission boundary ARN)
     - `SNSTopicARN` (ARN for an existing SNS topic for alerts, or leave as an empty string to create a new one)
     - `OrganizationalUnit` (Identifier for Control Tower guardrail, e.g., `ou-example`)

3. **Deploy via AWS CLI:**
   ```bash
   aws cloudformation deploy \
     --template-file template.yaml \
     --stack-name SQSGuardrailStack \
     --parameter-overrides LambdaRuntime=python3.9 LambdaMemorySize=128 PermissionBoundaryARN=arn:aws:iam::123456789012:policy/YourPermissionBoundary SNSTopicARN=arn:aws:sns:us-east-1:123456789012:YourSNSTopic OrganizationalUnit=ou-example \
     --capabilities CAPABILITY_NAMED_IAM

4. Deploy via AWS Console:
  - Open the AWS CloudFormation console.
  - Create a new stack by uploading the template.yaml file.
  - Provide the required parameter values when prompted.

## Design Decisions
### Guardrail via CloudFormation:
  The solution uses a YAML-only CloudFormation template to create a Python Lambda function, an IAM role with an attached permission boundary, an EventBridge rule (triggered by SQS queue creation events), and a Control Tower enabled control to enforce that any SQS queue must have a dead-letter queue configured in us-east-1.

### Lambda Function Checks:
  The Lambda function validates that:

### A VPC endpoint for SQS exists.
  The SQS queue has encryption enabled.
  The queue uses a customer-managed key (CMK) instead of an AWS-managed key.
  The queue includes required tags: Name, Created By, and Cost Center.
  If any check fails, an alert is triggered via SNS (or the event is logged).

### Permission Boundary:
  The Lambda execution role is provisioned with a permission boundary. This ensures that even if the function code is updated, it cannot exceed the permissions defined by your organization's policy. This approach supports multi-account deployments by centralizing control.

### Bonus: GitHub Actions CI/CD Workflow
  A GitHub Actions workflow (.github/workflows/ci.yml) is included to demonstrate CI/CD best practices. The workflow performs the following tasks:

  - Code Checkout: Retrieves the repository code.
  - Python Setup and Linting: Installs Python 3.9 and runs flake8 to check the Lambda function code for issues.
  - YAML Linting: Installs yamllint to validate the syntax of template.yaml.
  - Test Deployment: Optionally deploys the CloudFormation stack using AWS CLI (this step requires AWS credentials and a valid permission  boundary ARN configured in repository secrets).
  This automation helps catch syntax or configuration errors early and ensures that the CloudFormation template is deployable.  

