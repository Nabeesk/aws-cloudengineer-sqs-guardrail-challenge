# SecretCode: nabeesk-2025-ABC
"""
Lambda function for SQS Security Compliance Guardrail.

This function is triggered by an EventBridge event when a new SQS queue is created.
It performs the following security checks:
  - VPC endpoint for SQS exists.
  - SQS queue has encryption enabled.
  - SQS queue uses a customer-managed key (CMK).
  - SQS queue has required tags: Name, Created By, and Cost Center.

If any check fails, an alert is triggered via SNS (if configured) or logged.
"""

import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sqs_client = boto3.client('sqs')
ec2_client = boto3.client('ec2')
sns_client = boto3.client('sns')

def check_vpc_endpoint():
    """Check if a VPC endpoint for SQS exists."""
    try:
        response = ec2_client.describe_vpc_endpoints(
            Filters=[{'Name': 'service-name', 'Values': ['com.amazonaws.us-east-1.sqs']}]
        )
        endpoints = response.get('VpcEndpoints', [])
        return len(endpoints) > 0
    except Exception as e:
        logger.error("Error checking VPC endpoints: %s", str(e))
        return False

def check_encryption(queue_url):
    """Check if the SQS queue has encryption enabled."""
    try:
        attributes = sqs_client.get_queue_attributes(
            QueueUrl=queue_url,
            AttributeNames=['All']
        )['Attributes']
        return attributes.get('KmsMasterKeyId') is not None
    except Exception as e:
        logger.error("Error checking encryption for %s: %s", queue_url, str(e))
        return False

def check_customer_managed_key(queue_url):
    """Verify the SQS queue uses a customer-managed key."""
    try:
        attributes = sqs_client.get_queue_attributes(
            QueueUrl=queue_url,
            AttributeNames=['All']
        )['Attributes']
        key_id = attributes.get('KmsMasterKeyId', '')
        # AWS-managed keys typically start with "alias/aws/"
        return not key_id.startswith("alias/aws/")
    except Exception as e:
        logger.error("Error checking CMK for %s: %s", queue_url, str(e))
        return False

def check_tags(queue_url):
    """Check that the queue has required tags."""
    try:
        tags = sqs_client.list_queue_tags(QueueUrl=queue_url).get('Tags', {})
        required_tags = ['Name', 'Created By', 'Cost Center']
        return all(tag in tags for tag in required_tags)
    except Exception as e:
        logger.error("Error checking tags for %s: %s", queue_url, str(e))
        return False

def publish_alert(message, sns_topic_arn):
    """Publish an alert message to SNS if a topic ARN is provided."""
    try:
        if sns_topic_arn:
            sns_client.publish(TopicArn=sns_topic_arn, Message=message)
        else:
            logger.warning("SNS Topic ARN not provided. Alert: %s", message)
    except Exception as e:
        logger.error("Error publishing alert: %s", str(e))

def lambda_handler(event, context):
    """
    Lambda function entry point.
    Expects event to contain SQS queue details and optional SNSTopicARN.
    """
    logger.info("Received event: %s", json.dumps(event))
    sns_topic_arn = event.get('SNSTopicARN', '')
    queue_url = event.get('detail', {}).get('requestParameters', {}).get('queueUrl')
    if not queue_url:
        logger.error("Queue URL not found in event.")
        return {"statusCode": 400, "body": "Queue URL not provided"}

    checks = {
        "vpc_endpoint": check_vpc_endpoint(),
        "encryption": check_encryption(queue_url),
        "customer_managed_key": check_customer_managed_key(queue_url),
        "tags": check_tags(queue_url)
    }

    failed_checks = [name for name, passed in checks.items() if not passed]

    if failed_checks:
        alert_message = f"SQS Guardrail Alert for {queue_url}: Failed checks: {', '.join(failed_checks)}"
        publish_alert(alert_message, sns_topic_arn)
        logger.error(alert_message)
    else:
        logger.info("All checks passed for %s", queue_url)

    return {
        "statusCode": 200,
        "body": json.dumps(checks)
    }
